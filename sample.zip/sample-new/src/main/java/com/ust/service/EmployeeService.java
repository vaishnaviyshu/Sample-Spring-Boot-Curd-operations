package com.ust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.ust.models.Employee;
import com.ust.repository.EmployeeRepository;


@Service
public class EmployeeService implements EmployeeServiceImpl{
	
	@Autowired
	EmployeeRepository emr;

	@Override
	public Employee addEmployee(Employee employee) {
		return emr.save(employee);
		
	}

	public List<Employee> getallemp(Employee em) {
		// TODO Auto-generated method stub
		return emr.findAll();
	}

	@Override
	public void deleteUserById(int id) {
		 try {
		      emr.deleteById(id);  
		    }catch(DataAccessException ex){
		      throw new RuntimeException(ex.getMessage());
		    }
		
	}

	@Override
	public void updateUser(Employee user) {
		 // check if the user with the passed id exists or not
		Employee userDB = emr.findById(user.getId()).orElseThrow();
	    // If user exists then updated
	    emr.save(user);
	  }
	
	
	

}
