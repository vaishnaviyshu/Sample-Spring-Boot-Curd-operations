package com.ust.service;

import java.util.List;

import com.ust.models.Employee;

public interface EmployeeServiceImpl {
	
	public Employee addEmployee(Employee employee);

	public List<Employee> getallemp(Employee em);

	public void deleteUserById(int id);

	public void updateUser(Employee user);
	 

}
